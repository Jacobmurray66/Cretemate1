
export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <h2>Dashboard (Placeholder)</h2>
      <p>Total Revenue: $0.00</p>
      <p>Total Expenses: $0.00</p>
      <p>Net Profit: $0.00</p>
    </div>
  );
}
