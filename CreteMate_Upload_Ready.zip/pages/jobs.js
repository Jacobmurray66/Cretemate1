
import { useState } from 'react';

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [job, setJob] = useState({ address: '', footage: '', scope: '', estimate: '', expenses: '' });

  const addJob = () => {
    setJobs([...jobs, job]);
    setJob({ address: '', footage: '', scope: '', estimate: '', expenses: '' });
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Job Tracker</h2>
      <input placeholder="Address" value={job.address} onChange={e => setJob({ ...job, address: e.target.value })} /><br />
      <input placeholder="Footage" value={job.footage} onChange={e => setJob({ ...job, footage: e.target.value })} /><br />
      <input placeholder="Scope" value={job.scope} onChange={e => setJob({ ...job, scope: e.target.value })} /><br />
      <input placeholder="Estimate ($)" value={job.estimate} onChange={e => setJob({ ...job, estimate: e.target.value })} /><br />
      <input placeholder="Expenses ($)" value={job.expenses} onChange={e => setJob({ ...job, expenses: e.target.value })} /><br />
      <button onClick={addJob}>Add Job</button>

      <div>
        {jobs.map((j, i) => (
          <div key={i} style={{ marginTop: 10, padding: 10, border: '1px solid gray' }}>
            <p><strong>{j.address}</strong></p>
            <p>Footage: {j.footage} sq ft</p>
            <p>Scope: {j.scope}</p>
            <p>Estimate: ${j.estimate}</p>
            <p>Expenses: ${j.expenses}</p>
            <p>Profit: ${parseFloat(j.estimate || 0) - parseFloat(j.expenses || 0)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
