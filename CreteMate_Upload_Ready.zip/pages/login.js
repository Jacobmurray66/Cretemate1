
export default function Login() {
  return (
    <div style={{ padding: 20 }}>
      <h2>Login Page (Placeholder)</h2>
      <input type="text" placeholder="Email" /><br />
      <input type="password" placeholder="Password" /><br />
      <button>Login</button>
    </div>
  );
}
