// Login page placeholder
export default function LoginPage() { return <div>Login Page (placeholder)</div>; }