// Jobs page placeholder
export default function Jobs() { return <div>Jobs Page (placeholder)</div>; }