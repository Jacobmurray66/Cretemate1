// Dashboard placeholder
export default function Dashboard() { return <div>Dashboard (placeholder)</div>; }