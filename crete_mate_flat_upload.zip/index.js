
import { useState } from "react";

export default function CreteMateApp() {
  const [job, setJob] = useState({
    address: "",
    footage: "",
    scope: "",
    status: "Scheduled",
  });

  const [jobs, setJobs] = useState([]);

  const addJob = () => {
    if (job.address && job.footage && job.scope) {
      setJobs([...jobs, job]);
      setJob({ address: "", footage: "", scope: "", status: "Scheduled" });
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>CreteMate – Job Tracker</h1>
      <div style={{ marginBottom: 20 }}>
        <input
          placeholder="Job Address"
          value={job.address}
          onChange={(e) => setJob({ ...job, address: e.target.value })}
        />
        <input
          placeholder="Square Footage"
          value={job.footage}
          onChange={(e) => setJob({ ...job, footage: e.target.value })}
        />
        <textarea
          placeholder="Scope of Work"
          value={job.scope}
          onChange={(e) => setJob({ ...job, scope: e.target.value })}
        />
        <button onClick={addJob}>Add Job</button>
      </div>

      <div>
        {jobs.map((j, i) => (
          <div key={i} style={{ border: "1px solid #ccc", marginBottom: 10, padding: 10 }}>
            <p><strong>Address:</strong> {j.address}</p>
            <p><strong>Footage:</strong> {j.footage} sq ft</p>
            <p><strong>Scope:</strong> {j.scope}</p>
            <p><strong>Status:</strong> {j.status}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
